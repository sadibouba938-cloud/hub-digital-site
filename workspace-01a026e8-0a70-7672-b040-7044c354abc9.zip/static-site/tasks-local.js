/**
 * Hub Digital — Tableau de bord (version statique)
 * Les tâches sont enregistrées dans le navigateur (localStorage).
 * Fonctionne sans serveur — parfait pour GitHub Pages.
 */
(function () {
  "use strict";

  var STORAGE_KEY = "hubDigitalTasks";
  var STATUS_FLOW = { todo: "in_progress", in_progress: "done", done: "todo" };
  var currentFilter = "all";
  var armedDelete = null;

  var $ = function (s) { return document.querySelector(s); };
  var $$ = function (s) { return Array.prototype.slice.call(document.querySelectorAll(s)); };

  /* ---------- Stockage local ---------- */
  function readAll() {
    try {
      return JSON.parse(localStorage.getItem(STORAGE_KEY)) || [];
    } catch (e) {
      return [];
    }
  }
  function writeAll(list) {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(list));
    } catch (e) { /* stockage plein/indisponible */ }
  }

  function nowISO() {
    var d = new Date();
    function p(n) { return (n < 10 ? "0" : "") + n; }
    return d.getFullYear() + "-" + p(d.getMonth() + 1) + "-" + p(d.getDate()) + " " +
           p(d.getHours()) + ":" + p(d.getMinutes()) + ":" + p(d.getSeconds());
  }

  function addTask(title, description, status) {
    var list = readAll();
    var id = list.length ? Math.max.apply(null, list.map(function (t) { return t.id; })) + 1 : 1;
    var task = { id: id, title: title, description: description, status: status, created_at: nowISO(), updated_at: nowISO() };
    list.push(task);
    writeAll(list);
    return task;
  }

  function updateStatus(id, status) {
    var list = readAll();
    list.forEach(function (t) { if (t.id === id) { t.status = status; t.updated_at = nowISO(); } });
    writeAll(list);
  }

  function removeTask(id) {
    writeAll(readAll().filter(function (t) { return t.id !== id; }));
  }

  /* ---------- i18n ---------- */
  function lang() {
    var l = (document.documentElement.lang || "fr").toLowerCase().split("-")[0];
    return I18N[l] ? l : "fr";
  }
  function t(key) {
    var l = lang();
    if (I18N[l] && I18N[l][key] != null) return I18N[l][key];
    if (I18N.fr && I18N.fr[key] != null) return I18N.fr[key];
    return key;
  }

  function toast(msg, isErr) {
    var el = $("#toast");
    el.textContent = msg;
    el.className = isErr ? "err show" : "show";
    clearTimeout(el._h);
    el._h = setTimeout(function () { el.className = ""; }, 2600);
  }

  function esc(s) {
    return (s == null ? "" : String(s)).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }

  function fmtDate(iso) {
    if (!iso) return "";
    var d = new Date(String(iso).replace(" ", "T"));
    if (isNaN(d.getTime())) return iso;
    return d.toLocaleDateString(lang() === "ar" ? "ar" : "fr-FR", { day: "2-digit", month: "short" }) +
           " " + d.toLocaleTimeString(lang() === "ar" ? "ar" : "fr-FR", { hour: "2-digit", minute: "2-digit" });
  }

  /* ---------- Rendu ---------- */
  function loadStats() {
    var list = readAll();
    function count(s) { return list.filter(function (x) { return x.status === s; }).length; }
    $("#st-total").textContent = list.length;
    $("#st-todo").textContent = count("todo");
    $("#st-prog").textContent = count("in_progress");
    $("#st-done").textContent = count("done");
  }

  function advanceHint(status) {
    if (status === "todo") return t("dash.advanceTodo");
    if (status === "in_progress") return t("dash.advanceInProgress");
    return t("dash.advanceDone");
  }

  function renderList() {
    var list = readAll();
    var filtered = currentFilter === "all" ? list : list.filter(function (x) { return x.status === currentFilter; });
    filtered.sort(function (a, b) { return b.id - a.id; });

    var box = $("#list");
    if (!filtered.length) {
      box.innerHTML = '<div class="empty"><div class="big">📭</div>' + esc(t("dash.empty")) + "</div>";
      return;
    }
    box.innerHTML = filtered.map(function (task) {
      var armed = armedDelete === task.id;
      return (
        '<div class="task">' +
          '<div class="body">' +
            '<div class="title">' + esc(task.title) + "</div>" +
            (task.description ? '<div class="desc">' + esc(task.description) + "</div>" : "") +
            '<div class="meta">#' + task.id + " · " + esc(t("dash.created")) + " " + fmtDate(task.created_at) +
              (task.updated_at !== task.created_at ? " · " + esc(t("dash.updated")) + " " + fmtDate(task.updated_at) : "") +
            "</div>" +
          "</div>" +
          '<span class="badge ' + task.status + '">' + esc(t("status." + task.status)) + "</span>" +
          '<div class="actions">' +
            '<button class="icon-btn" title="' + esc(advanceHint(task.status)) + '" data-advance="' + task.id + '">➡️</button>' +
            '<button class="icon-btn del' + (armed ? " armed" : "") + '" title="' + esc(t("dash.delete")) + '" data-del="' + task.id + '">' + (armed ? "✔" : "🗑") + "</button>" +
          "</div>" +
        "</div>"
      );
    }).join("");
    loadStats();
  }

  /* ---------- Actions ---------- */
  function onAdd(e) {
    e.preventDefault();
    var title = $("#f-title").value.trim();
    if (!title) return;
    addTask(title, $("#f-desc").value.trim(), $("#f-status").value);
    $("#add-form").reset();
    toast(t("dash.toastAdded"));
    renderList();
  }

  function onAdvance(id) {
    var task = readAll().find(function (x) { return x.id === id; });
    if (!task) return;
    updateStatus(id, STATUS_FLOW[task.status] || "todo");
    toast(t("dash.toastUpdated"));
    renderList();
  }

  function onDelete(id) {
    if (armedDelete !== id) {
      armedDelete = id;
      renderList();
      setTimeout(function () { if (armedDelete === id) { armedDelete = null; renderList(); } }, 3000);
      return;
    }
    armedDelete = null;
    removeTask(id);
    toast(t("dash.toastDeleted"));
    renderList();
  }

  /* ---------- Init ---------- */
  document.addEventListener("DOMContentLoaded", function () {
    $("#add-form").addEventListener("submit", onAdd);
    $("#list").addEventListener("click", function (e) {
      var adv = e.target.closest("[data-advance]");
      var del = e.target.closest("[data-del]");
      if (adv) onAdvance(parseInt(adv.getAttribute("data-advance"), 10));
      else if (del) onDelete(parseInt(del.getAttribute("data-del"), 10));
    });
    $("#filters").addEventListener("click", function (e) {
      var chip = e.target.closest(".dash-chip");
      if (!chip) return;
      currentFilter = chip.getAttribute("data-f");
      $$(".dash-chip").forEach(function (c) { c.classList.remove("active"); });
      chip.classList.add("active");
      renderList();
    });
    $$(".lang-btn").forEach(function (btn) {
      btn.addEventListener("click", function () { setTimeout(renderList, 0); });
    });
    renderList();
  });
})();

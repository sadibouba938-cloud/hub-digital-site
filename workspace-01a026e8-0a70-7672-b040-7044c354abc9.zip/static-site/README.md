# Hub Digital — Version statique (GitHub Pages)

Cette version fonctionne **sans serveur** : tout est du HTML/CSS/JS pur.
Parfaite pour vos GitHub Pages existants.

## 📁 Contenu

```
├── index.html          # Vitrine Hub Digital (+ boutique + chat IA)
├── taches.html         # Tableau de bord (tâches en localStorage)
├── products.json       # Produits de la boutique (copie de secours)
├── tasks-local.js      # Logique du tableau de bord (navigateur)
├── chat.js / chat.css  # Widget « Hub Digital IA » (réponses locales FR/EN/AR)
└── assets/             # css + js (design + i18n)
```

## ✅ Ce qui fonctionne en statique

- Vitrine complète (hero, services, à propos, processus, projets, témoignages, FAQ, contact)
- Multilingue FR / EN / AR (RTL)
- **Boutique** : les produits sont chargés en direct depuis l'API Chariow
  (`api-edge.chariow.com`), avec repli automatique sur `products.json` si l'API est inaccessible.
- **Chat IA** : réponses locales (FAQ), sans serveur.
- **Tableau de bord** : les tâches sont enregistrées dans le **navigateur du visiteur**
  (localStorage) — chaque visiteur a ses propres tâches.

## 🚀 Déploiement sur GitHub Pages

1. Créez (ou utilisez) un dépôt GitHub.
2. Déposez **tout le contenu de ce dossier** à la racine du dépôt.
3. GitHub → **Settings → Pages → Source : Deploy from a branch → `main` / root**.
4. Le site est publié sur `https://<votre-utilisateur>.github.io/<dépôt>/`.

## ⚠️ Limites de la version statique

- Le tableau de bord n'est **pas partagé** entre visiteurs (données locales au navigateur).
- Si vous ajoutez un produit dans votre boutique Chariow, il apparaîtra automatiquement
  (chargement en direct) ; sinon, mettez à jour `products.json`.

Pour une version **avec vraie base de données partagée**, utilisez le dossier `deploy/`
(FastAPI + SQLite) à déployer sur Railway/Render.

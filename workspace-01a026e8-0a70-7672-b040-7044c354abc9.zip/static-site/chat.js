/**
 * Hub Digital — Widget de chat « Hub Digital IA » (version statique)
 * Répond localement (FAQ FR/EN/AR), sans serveur.
 */
(function () {
  "use strict";

  function container(id) { return document.getElementById(id); }

  function msgEl(cls, text) {
    var d = document.createElement("div");
    d.className = "message " + cls;
    d.textContent = text;
    return d;
  }

  function append(box, cls, text) {
    box.appendChild(msgEl(cls, text));
    box.scrollTop = box.scrollHeight;
  }

  function welcome() {
    var w = container("chat-window");
    if (w && !w.dataset.welcomed) {
      w.dataset.welcomed = "1";
      append(w, "agent", "Bonjour 👋 Je suis Hub Digital IA. Posez-moi une question sur nos services, notre boutique ou nos contacts !");
    }
  }

  /* --- Réponses locales (FAQ) --- */
  var TOPICS = [
    { keys: ["bonjour", "salut", "bonsoir", "salam", "hello", "hi", "مرحبا", "سلام"],
      fr: "Bonjour 👋 Je suis l'assistant de Hub Digital. Je peux vous renseigner sur nos services, notre boutique et nos contacts.",
      en: "Hello 👋 I'm the Hub Digital assistant. I can tell you about our services, store and contacts.",
      ar: "مرحباً 👋 أنا مساعد Hub Digital. يمكنني إخبارك عن خدماتنا ومتجرنا وطرق التواصل." },
    { keys: ["service", "offre", "prestation", "branding", "storytelling", "e-commerce", "marketing", "stratégie", "خدمات"],
      fr: "Nous proposons : 🎨 Branding & Identité, 📖 Storytelling, 💻 Solutions digitales, 📈 Stratégie de croissance et 🛒 E-commerce.",
      en: "We offer: 🎨 Branding & Identity, 📖 Storytelling, 💻 Digital solutions, 📈 Growth strategy and 🛒 E-commerce.",
      ar: "نقدم: 🎨 الهوية البصرية، 📖 سرد القصص، 💻 الحلول الرقمية، 📈 استراتيجية النمو و 🛒 التجارة الإلكترونية." },
    { keys: ["boutique", "produit", "produits", "prix", "acheter", "chariow", "shop", "store", "product", "buy", "combien", "tarif", "coûte", "coute", "startpack", "visionai", "kit", "cost", "how much", "متجر", "منتج", "سعر", "كم"],
      fr: "🛍️ Notre boutique est dans la section « Boutique » du site et sur qxcvjkbl.mychariow.market : StartPack Digital, VisionAI, kits IA & marketing…",
      en: "🛍️ Our store is in the « Boutique » section and at qxcvjkbl.mychariow.market: StartPack Digital, VisionAI, AI & marketing kits…",
      ar: "🛍️ متجرنا موجود في قسم « المتجر » وعلى الرابط qxcvjkbl.mychariow.market." },
    { keys: ["contact", "email", "mail", "téléphone", "tel", "joindre", "adresse", "اتصال", "بريد"],
      fr: "📬 Vous pouvez nous écrire à contact@hubdigital.com ou utiliser le formulaire « Contact » en bas de la page.",
      en: "📬 Email us at contact@hubdigital.com or use the « Contact » form at the bottom of the page.",
      ar: "📬 يمكنك مراسلتنا على contact@hubdigital.com أو استخدام نموذج « اتصل بنا »." },
    { keys: ["tache", "tâche", "tableau de bord", "dashboard", "لوحة", "مهام"],
      fr: "🗂️ Le tableau de bord est accessible via le menu « Tableau de bord » (ou /taches).",
      en: "🗂️ The dashboard is available in the « Dashboard » menu (or /taches).",
      ar: "🗂️ لوحة التحكم متاحة من قائمة « لوحة التحكم » (أو /taches)." },
    { keys: ["à propos", "a propos", "qui êtes", "hub digital", "about", "من أنت", "هب ديجيتال"],
      fr: "🚀 Hub Digital est la vitrine numérique d'un projet innovant qui connecte créativité et technologie, pensé pour le marché africain et international.",
      en: "🚀 Hub Digital is the digital showcase of an innovative project connecting creativity and technology, built for the African and international market.",
      ar: "🚀 Hub Digital هو الواجهة الرقمية لمشروع مبتكر يربط الإبداع بالتكنولوجيا." },
    { keys: ["merci", "thank", "شكرا"],
      fr: "Avec plaisir ! 😊 N'hésitez pas si vous avez d'autres questions.",
      en: "You're welcome! 😊 Feel free to ask anything else.",
      ar: "على الرحب والسعة! 😊" }
  ];

  function langOf(m) {
    var ar = ["مرحبا", "سلام", "عليكم", "شكرا", "بوتيك", "متجر", "منتج", "سعر", "خدمات", "اتصال", "مهام"];
    if (ar.some(function (w) { return m.indexOf(w) !== -1; })) return "ar";
    var en = ["hello", " hi", "how", "what", "thank", "price", " buy", "the ", "your", "help", "cost", "much", "dashboard"];
    var fr = ["bonjour", "salut", "merci", "combien", "comment", "quel", "quelle", "quoi", "vos", "nos", "notre", "boutique", "prix", "tache", "tâche", "tableau", "contacter", "service", "offre", "tarif"];
    if (en.some(function (w) { return m.indexOf(w) !== -1; }) && !fr.some(function (w) { return m.indexOf(w) !== -1; })) return "en";
    return "fr";
  }

  function replyTo(message) {
    var m = " " + message.toLowerCase() + " ";
    var lang = langOf(m);
    for (var i = 0; i < TOPICS.length; i++) {
      var t = TOPICS[i];
      if (t.keys.some(function (k) { return m.indexOf(k) !== -1; })) return t[lang];
    }
    return { fr: "Je ne suis pas sûr de comprendre 🤔 Posez-moi une question sur nos services, notre boutique ou nos contacts.",
             en: "I'm not sure I understand 🤔 Ask me about our services, store or contacts.",
             ar: "لست متأكداً من فهمي لسؤالك 🤔 اسألني عن خدماتنا أو متجرنا." }[lang];
  }

  window.sendMessage = function () {
    var input = container("chat-input");
    var inlineInput = container("userInput");
    var message = "";
    var box = null;
    var field = null;

    if (input && input.value.trim()) { message = input.value.trim(); box = container("chat-window"); field = input; }
    else if (inlineInput && inlineInput.value.trim()) { message = inlineInput.value.trim(); box = container("response"); field = inlineInput; }

    if (!message || !box) return;

    append(box, "user", message);
    field.value = "";

    var typing = msgEl("agent", "…");
    box.appendChild(typing);
    box.scrollTop = box.scrollHeight;

    setTimeout(function () {
      typing.textContent = replyTo(message);
      box.scrollTop = box.scrollHeight;
    }, 500);
  };

  ["chat-input", "userInput"].forEach(function (id) {
    var el = container(id);
    if (el) {
      el.addEventListener("keydown", function (e) {
        if (e.key === "Enter") { e.preventDefault(); window.sendMessage(); }
      });
    }
  });

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", welcome);
  } else {
    welcome();
  }
})();
